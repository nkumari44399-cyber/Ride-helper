package com.myhelper.ride

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AutoAcceptService : AccessibilityService() {

    private val kmRe = Regex("^\\s*(\\d+(?:\\.\\d+)?)\\s*km\\b", RegexOption.IGNORE_CASE)
    private val fareRe = Regex("₹\\s*(\\d+)")
    private var lastClick = 0L
    private var lastSkipSig = ""
    private var lastSkipTime = 0L
    private var lastKnownPkg = ""

    private val handler = Handler(Looper.getMainLooper())
    // PRO MODE: event ka intezaar kiye bina, har 50ms mein khud check karta hai
    private val fastLoop = object : Runnable {
        override fun run() {
            try { scanAndAct(lastKnownPkg) } catch (e: Exception) { }
            handler.postDelayed(this, 50)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.post(fastLoop)
    }

    override fun onDestroy() {
        handler.removeCallbacks(fastLoop)
        super.onDestroy()
    }

    private fun allRoots(): List<AccessibilityNodeInfo> {
        val list = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) {
                val r = w.root
                if (r != null) list.add(r)
            }
        } catch (e: Exception) { }
        val active = rootInActiveWindow
        if (active != null && !list.contains(active)) list.add(active)
        return list
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        lastKnownPkg = pkg
        val prefs = Store.prefs(this)
        prefs.edit()
            .putString("lastPkg", pkg)
            .putLong("lastPkgTime", System.currentTimeMillis())
            .apply()
        scanAndAct(pkg)
    }

    private fun isAcceptLabel(raw: String): Boolean {
        val t = raw.trim().lowercase()
        if (t.isEmpty()) return false
        if (t.contains("accepted")) return false // "You missed" / already accepted text se bachne ke liye
        if (t == "accept" || t.startsWith("accept ")) return true
        if (t == "स्वीकार करें" || t == "स्वीकार" || t.startsWith("स्वीकार")) return true
        return false
    }

    private fun scanAndAct(pkgIn: String) {
        if (pkgIn.isEmpty()) return
        val prefs = Store.prefs(this)
        val target = prefs.getString("pkg", "com.rapido.rider")?.trim().orEmpty()
        val isRapido = pkgIn.contains("rapido", true) || (target.isNotEmpty() && pkgIn == target)
        if (!isRapido) return

        val roots = allRoots()
        if (roots.isEmpty()) return

        // ---- DEBUG info ----
        val allTexts = ArrayList<String>()
        for (r in roots) collect(r) { t -> if (t.isNotBlank()) allTexts.add(t) }
        val dump = allTexts.distinct().take(30).joinToString(" | ")
        var foundAny = false
        for (r in roots) if (findAccept(r) != null) { foundAny = true; break }
        prefs.edit()
            .putString("lastDump", dump)
            .putBoolean("lastFound", foundAny)
            .putLong("lastDumpTime", System.currentTimeMillis())
            .putInt("lastWindowCount", roots.size)
            .apply()

        if (!prefs.getBoolean("enabled", false)) return

        val now = System.currentTimeMillis()
        if (now - lastClick < 900) return

        var button: AccessibilityNodeInfo? = null
        var sourceRoot: AccessibilityNodeInfo? = null
        for (r in roots) {
            val b = findAccept(r)
            if (b != null) { button = b; sourceRoot = r; break }
        }
        if (button == null || sourceRoot == null) return

        // ---- order mein text padhna: km, fare, aur un ke paas wala address ----
        val rawTexts = ArrayList<String>()
        collect(sourceRoot) { t -> rawTexts.add(t) }

        var fare = 0
        val kms = ArrayList<Double>()
        val addrs = ArrayList<String>()
        for ((idx, t) in rawTexts.withIndex()) {
            fareRe.findAll(t).forEach { fare = maxOf(fare, it.groupValues[1].toInt()) }
            val m = kmRe.find(t)
            if (m != null) {
                kms.add(m.groupValues[1].toDouble())
                var addr = ""
                for (j in idx + 1 until rawTexts.size) {
                    val cand = rawTexts[j].trim()
                    if (cand.isEmpty()) continue
                    if (kmRe.matches(cand)) continue
                    if (fareRe.matches(cand)) continue
                    if (isAcceptLabel(cand)) continue
                    addr = cand
                    break
                }
                addrs.add(addr)
            }
        }
        val pickup = kms.getOrNull(0)
        val drop = kms.getOrNull(1)
        val pStr = pickup?.toString() ?: ""
        val dStr = drop?.toString() ?: ""
        val pAddr = addrs.getOrNull(0) ?: ""
        val dAddr = addrs.getOrNull(1) ?: ""

        val minFare = prefs.getInt("minFare", 0)
        val maxPickup = prefs.getFloat("maxPickup", 0f)
        val maxDrop = prefs.getFloat("maxDrop", 0f)

        var reason: String? = null
        if (minFare > 0 && fare < minFare) reason = "Fare kam (₹$fare)"
        else if (maxPickup > 0f && pickup != null && pickup > maxPickup) reason = "Pickup door ($pStr km)"
        else if (maxDrop > 0f && drop != null && drop > maxDrop) reason = "Drop door ($dStr km)"

        if (reason != null) {
            val sig = "$fare|$pStr|$dStr|$reason"
            if (sig != lastSkipSig || now - lastSkipTime > 8000) {
                lastSkipSig = sig
                lastSkipTime = now
                Store.bump(this, "skipCount")
                Store.addHistory(this, "S", fare, pStr, dStr, pAddr, dAddr, reason)
            }
            return
        }

        if (clickNode(button)) {
            lastClick = now
            Store.bump(this, "count")
            Store.addHistory(this, "A", fare, pStr, dStr, pAddr, dAddr, "Accepted")
            if (prefs.getBoolean("vibrate", true)) {
                @Suppress("DEPRECATION")
                (getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.vibrate(150L)
            }
        }
    }

    private fun collect(node: AccessibilityNodeInfo, f: (String) -> Unit) {
        node.text?.toString()?.let { f(it) }
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            collect(c, f)
        }
    }

    private fun findAccept(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val t = node.text?.toString()
        if (t != null && isAcceptLabel(t)) return node
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            findAccept(c)?.let { return it }
        }
        return null
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        while (cur != null) {
            if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
        }
        return false
    }

    override fun onInterrupt() {}
}
