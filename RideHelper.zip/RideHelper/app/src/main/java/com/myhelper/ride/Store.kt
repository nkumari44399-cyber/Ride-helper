package com.myhelper.ride

import android.content.Context
import java.text.SimpleDateFormat
import java.util.*

object Store {
    fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    private fun today() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    fun bump(c: Context, key: String) {
        val p = prefs(c)
        val e = p.edit()
        val fresh = p.getString("countDate", "") != today()
        if (fresh) e.putString("countDate", today()).putInt("count", 0).putInt("skipCount", 0)
        val base = if (fresh) 0 else p.getInt(key, 0)
        e.putInt(key, base + 1).apply()
    }

    fun todayCount(c: Context, key: String): Int {
        val p = prefs(c)
        return if (p.getString("countDate", "") == today()) p.getInt(key, 0) else 0
    }

    fun resetToday(c: Context) {
        prefs(c).edit().putInt("count", 0).putInt("skipCount", 0).apply()
    }

    private fun clean(s: String) = s.replace("|", " ").replace("\n", " ").trim().take(200)

    // type: A (accepted) / S (skipped)
    // fields: type|time|fare|pickupKm|dropKm|pickupAddr|dropAddr|note
    fun addHistory(
        c: Context, type: String, fare: Int, pickupKm: String, dropKm: String,
        pickupAddr: String, dropAddr: String, note: String
    ) {
        val p = prefs(c)
        val line = listOf(
            type, System.currentTimeMillis().toString(), fare.toString(),
            pickupKm, dropKm, clean(pickupAddr), clean(dropAddr), clean(note)
        ).joinToString("|")
        val old = (p.getString("history", "") ?: "").split("\n").filter { it.isNotBlank() }
        p.edit().putString("history", (listOf(line) + old).take(80).joinToString("\n")).apply()
    }

    fun history(c: Context): List<List<String>> =
        (prefs(c).getString("history", "") ?: "").split("\n")
            .filter { it.isNotBlank() }.map { it.split("|") }.filter { it.size >= 6 }

    fun clearHistory(c: Context) {
        prefs(c).edit().remove("history").apply()
    }
}
